from graphviz import Digraph, Graph

def node2str(node, sep = ''):
    if isinstance(node, set) or isinstance(node, frozenset):
        return sep.join(sorted(map(str, node)))
    else:
        return str(node)

class LabelledGraph(object):

    def __init__(self, arcs, S = None, F = None, large_labels = False):
        self.S = S
        self.F = set() if F is None else F
        self.arcs = arcs if len(arcs) == 0 or len(arcs[0]) == 3 else tuple((X, '', Y) for X, Y in arcs)
        self.large_labels = large_labels
        if large_labels:
            self.tostr = lambda s: node2str(s, '\n')
            self.node_attr = {'margin': '.05'}  # 'width': '0', 'height': '0'}
        else:
            self.tostr = node2str
            self.node_attr = {}
        self.G = None

    @classmethod
    def from_automaton(cls, A):
        return cls(A.transitions, A.q0, A.F)

    @classmethod
    def from_lr(cls, STATES, GOTO):
        transitions = [(STATES[s], X, STATES[t]) for s in GOTO for X, t in GOTO[s].items() if t]
        return cls(transitions, STATES[0], [s for s in STATES if any(item.pos == len(item.rhs) for item in s)], True)

    def dot(self):
        if self.G: return self.G
        tostr = self.tostr
        node2id = lambda n: str(hash(frozenset(n))) if isinstance(n, set) else str(hash(n))
        add_node = lambda n: G.node(node2id(n), label = tostr(n), peripheries = '2' if n in self.F else '1')
        G = Digraph(graph_attr = {
                    'rankdir': 'LR',
                    'size': '8'
                },
                node_attr = self.node_attr,
                engine = 'dot'
            )
        if self.S is not None:
            G.node('#START#', label = '', shape = 'none')
            G.edge('#START#', node2id(self.S))
        for X, x, Y in self.arcs:
            add_node(X)
            add_node(Y)
            if self.large_labels: 
                G.edge(node2id(X), node2id(Y), xlabel = x)
            else:
                G.edge(node2id(X), node2id(Y), label = x)
        self.G = G
        return G

    def _repr_svg_(self):
        return self.dot()._repr_svg_()


class Tree(object):
    
    def __init__(self, root, children=None):
        self.root = root
        self.children = children if children else []

    def __repr__(self):
        def walk(T):
            return '({}: {})'.format(T.root, ', '.join(map(walk, T.children))) if T.children else T.root
        return walk(self)

    @classmethod
    def from_lol(cls, nl):
        def _to_tree(lst):
            return cls(str(lst[0]), [_to_tree(sl) for sl in lst[1:]])
        return _to_tree(nl)
    
    def nlstr(self):
        res = []

        def walk(T, d):
            res.append(' ' * d + T.root)
            for c in T.children:
                walk(c, d + 1)

        walk(self, 0)
        return '\n'.join(res)

    def dot(self):
        def walk(T, parent):
            if parent:
                g.node(str(id(T)), T.root)
                g.edge(str(id(parent)), str(id(T)))
            with g.subgraph() as s:
                s.attr('edge', style='invis')
                s.attr(rank='same')
                for f, t in zip(T.children, T.children[1:]):
                    s.edge(str(id(f)), str(id(t)))
            for child in T.children:
                walk(child, T)

        g = Graph()
        g.attr('node', shape='box')
        g.attr('node', margin='.05')
        g.attr('node', width='0')
        g.attr('node', height='0')
        g.attr('node', style='rounded, setlinewidth(.25)')
        g.attr('graph', nodesep='.25')
        g.attr('graph', ranksep='.25')
        g.node(str(id(self)), self.root)
        walk(self, None)
        return g

    def _repr_svg_(self):
        return self.dot()._repr_svg_()

class ProductionGraph(object):

    def __init__(self, derivation):
        self.derivation = derivation.copy()

    def __repr__(self):
        return 'ProductionGraph({})'.format(self.derivation)

    def dot(self):
        derivation = self.derivation
        G = Graph()
        G.attr('edge', penwidth = '.5')
        G.attr('edge', arrowsize = '.5')
        #G.attr('node', shape = 'plain')
        #G.attr('graph', nodesep='.0')
        #G.attr('graph', ranksep='.0')
        G.attr('node', shape='box')
        G.attr('node', margin='.05')
        G.attr('node', width='0')
        G.attr('node', height='0')
        G.attr('node', style='rounded, setlinewidth(.25)')
        G.attr('graph', nodesep='.25')
        G.attr('graph', ranksep='.25')

        sentence = ['{}_0'.format(derivation.G.S)]
        for step, (rule, pos) in enumerate(derivation.steps(), 1):
            lhs, rhs = derivation.G.P[rule]
            rhsn = [f'{X}_{step}{p}' for p, X in enumerate(rhs)]
                    
            if len(lhs) == 1:
                
                frm = sentence[pos]
                G.node(frm, label = frm.split('_')[0])

                for to in rhsn:
                    G.node(to, label = to.split('_')[0])
                    G.edge(frm, to)
                
            else:    
                G.node(f's{step}r{rule}', shape = 'point', width= '.07', height='.07')

                for frm in sentence[pos:pos + len(lhs)]:
                    G.node(frm, label = frm.split('_')[0])
                    G.edge(frm, f's{step}r{rule}', arrowsize = '0')

                for to in rhsn:
                    G.node(to, label = to.split('_')[0])
                    G.edge(f's{step}r{rule}', to)

            with G.subgraph() as s:
                s.attr('edge', style = 'invis')
                s.attr(rank = 'same')
                for f, t in zip(rhsn, rhsn[1:]):
                    s.edge(f, t)

                
                
            sentence = sentence[:pos] + rhsn + sentence[pos + len(lhs):]

        return G

    def _repr_svg_(self):
        return self.dot()._repr_svg_()