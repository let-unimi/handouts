from collections.abc import Set
from itertools import chain

from IPython.display import HTML


def peek(s):
    return next(iter(s)) if s else None

def union(s):
    return set().union(*s)

def _letsettostr(s):
    if isinstance(s, str):
        return s
    if isinstance(s, Set) and not s:
        return '{}'
    if isinstance(peek(s), str):
        return '{{{}}}'.format(', '.join(sorted(s)))
    else:
        return '{{{}}}'.format(', '.join(sorted(map(_letsettostr, s))))

def dod2html(dod):
    def fmt(r, c):
        if not c in dod[r]: return '&nbsp;'
        elem = dod[r][c]
        if elem is None: return '&nbsp;'
        if isinstance(elem, list) or isinstance(elem, tuple) or isinstance(elem, set):
            return ', '.join(map(str, elem))
        else:
            return str(elem)
    rows = sorted(dod.keys())
    cols = sorted(set(chain.from_iterable(dod[x].keys() for x in dod)))
    head = '<tr><td>&nbsp;<th>' + '<th>'.join(cols)
    body = '\n'.join('<tr><th>{}<td>{}'.format(r, '<td>'.join(fmt(r, c) for c in cols))for r in rows)
    return HTML('<table class="table table-bordered">\n{}\n{}\n</table>'.format(head, body))

class StatesQueueMap(object):

    def __init__(self, S0):
        self.queue = [S0]
        self.num = 0
        self.map = {frozenset(S0): 0, frozenset(): None}

    def getorput(self, IS):
        f = frozenset(IS)
        try:
            return self.map[f]
        except KeyError:
            self.num += 1
            self.map[f] = self.num
            self.queue.append(IS)
            return self.num

    def empty(self):
        return len(self.queue) == 0

    def pop(self):
        return self.queue.pop()

    def states(self):
        res = [None] * (1 + self.num)
        for IS, n in self.map.items():
            if n is not None: res[n] = set(IS)
        return res
