from collections import namedtuple
from itertools import chain
from operator import attrgetter

from . import ε
from .utils import _letsettostr


Production = namedtuple('Production', 'lhs, rhs')
Production.__repr__ = lambda self: '{} -> {}'.format(self.lhs, ''.join(self.rhs))

Item = namedtuple('Item', 'lhs, pos, rhs')
Item.__repr__ = lambda self: '{} -> {}•{}'.format(self.lhs, ''.join(self.rhs[:self.pos]), ''.join(self.rhs[self.pos:]))

EarleyItem = namedtuple('EarleyItem', 'lhs, pos, rhs, orig')
EarleyItem.__repr__ = lambda self: '{} -> {}•{}@{}'.format(self.lhs, ''.join(self.rhs[:self.pos]), ''.join(self.rhs[self.pos:]), self.orig)

class Grammar(object):

    def __init__(self, N, T, P, S):
        self.N = set(N)
        self.T = set(T)
        self.P = tuple(P)
        self.S = S

    @classmethod
    def from_string(cls, prods):
        P = []
        for p in prods.splitlines():
            if not p.strip(): continue
            lh, rha = p.split('->')
            for rh in rha.split('|'):
                P.append(Production(lh.strip(), tuple(rh.split())))
        P = tuple(P)
        S = P[0].lhs
        N = set(map(attrgetter('lhs'), P))
        T = set((chain.from_iterable(map(attrgetter('rhs'), P)))) - N - {ε}
        return cls(N, T, P, S)

    def rhs(self, N): 
        return (P.rhs for P in self.P if P.lhs == N)

    def __repr__ (self):
        return 'Grammar(N={}, T={}, P={}, S={})'.format(_letsettostr(self.N), _letsettostr(self.T), self.P, _letsettostr(self.S))
