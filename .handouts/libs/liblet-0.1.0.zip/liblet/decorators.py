from copy import deepcopy
from functools import wraps


def closure(f):
    @wraps(f)
    def _closure(*args):
        s, *other = args
        while True:
            n = f(deepcopy(s), *other)
            if n == s: return s
            s = n
    return _closure

def show_calls(ret_vals = False):
    def _show_calls(f):
        f.depth = 0
        @wraps(f)
        def wrapper(*args, **kwds):
            print('C' if ret_vals else '', ' ' * f.depth, *args, **kwds)
            f.depth += 1
            r = f(*args, **kwds)
            f.depth -= 1
            if ret_vals: print('R', ' ' * f.depth, r)
            return r
        return wrapper
    return _show_calls    
